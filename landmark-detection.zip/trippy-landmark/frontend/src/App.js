// frontend/src/App.js
import React, { useState } from 'react';
import axios from 'axios';

function App() {
  const [selectedFile, setSelectedFile] = useState(null);
  const [prediction, setPrediction] = useState(null);

  const handleFileChange = (event) => {
    setSelectedFile(event.target.files[0]);
  };

  const handleSubmit = async () => {
    const formData = new FormData();
    formData.append('file', selectedFile);

    try {
      const response = await axios.post('http://localhost:5000/predict', formData, {
        headers: {
          'Content-Type': 'multipart/form-data'
        }
      });

      setPrediction(response.data);
    } catch (error) {
      console.error('Error predicting:', error);
    }
  };

  return (
    <div>
      <input type="file" onChange={handleFileChange} />
      <button onClick={handleSubmit}>Predict</button>
      {prediction && (
        <div>
          <p>Predicted Landmark: {prediction.predicted_landmark}</p>
          <p>Location: {prediction.location}</p>
          <div dangerouslySetInnerHTML={{ __html: prediction.map_html }} />
        </div>
      )}
    </div>
  );
}

export default App;
