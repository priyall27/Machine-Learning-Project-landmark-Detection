# backend/app.py
from flask import Flask, request, jsonify
from flask_cors import CORS 
from PIL import Image
import numpy as np
import pandas as pd
import tensorflow as tf
import tensorflow_hub as hub
from geopy.geocoders import Nominatim
import folium

app = Flask(__name__)
cors = CORS(app, resources={r"/predict": {"origins": "http://localhost:3000"}})

landmark_model_url = 'https://tfhub.dev/google/on_device_vision/classifier/landmarks_classifier_asia_V1/1'
landmark_labels_path = 'landmarks_classifier_asia_V1_label_map.csv'
landmark_df = pd.read_csv('landmarks_classifier_asia_V1_label_map.csv')
landmark_labels = dict(zip(landmark_df.id, landmark_df.name))
img_shape = (321, 321)
landmark_classifier = tf.keras.Sequential(
    [hub.KerasLayer(landmark_model_url, input_shape=img_shape + (3,), output_key="predictions:logits")])

def predict_landmark_and_location(image):
    img = Image.open(image)
    img = img.resize(img_shape)
    img = np.array(img) / 255.0
    img = img[np.newaxis]

    # Predict landmark
    landmark_result = landmark_classifier.predict(img)
    predicted_landmark = landmark_labels[np.argmax(landmark_result)]

    # Get location address based on predicted landmark
    geolocator = Nominatim(user_agent='Your_Name')
    location = geolocator.geocode(predicted_landmark)

    map_html = get_map_html(location.latitude, location.longitude)

    return predicted_landmark, location.address, map_html

def get_map_html(latitude, longitude):
    m = folium.Map(location=[latitude, longitude], zoom_start=15)
    folium.Marker(location=[latitude, longitude], popup='Predicted Location').add_to(m)
    return m._repr_html_()

@app.route("/predict", methods=["POST"])
def predict():
    file = request.files["file"]
    predicted_landmark, location, map_html = predict_landmark_and_location(file)
    return jsonify({"predicted_landmark": predicted_landmark, "location": location, "map_html": map_html})

if __name__ == "__main__":
    app.run(debug=True)
